import telebot
import random
import hashlib
import webbrowser
from collections import defaultdict
from settings import API_TOKEN

bot = telebot.TeleBot(API_TOKEN)

# Хранение зарегистрированных пользователей и их паролей
users = {}
# Хранение активных пользователей для чата
active_chat_users = defaultdict(bool)

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Привет! Чтобы пользоваться анонимным чатом, зарегистрируйтесь на сайте с помощью команды /reg!")

@bot.message_handler(commands=['reg'])
def register(message):
    webbrowser.open('http://127.0.0.1:5000')
    bot.reply_to(message, 'Введите ваш пароль для завершения регистрации!')

@bot.message_handler(func=lambda message: True)
def check_password(message):
    user_password = message.text
    hashed_input_password = hash_password(user_password)

    # Проверка, зарегистрирован ли пользователь
    if message.from_user.id not in users:
        users[message.from_user.id] = hashed_input_password
        with open('password.txt', 'a') as file:
            file.write(f"{message.from_user.id}:{hashed_input_password}\n")
        bot.reply_to(message, 'Ура, вы зарегистрированы! Теперь вы можете пользоваться анонимным чатом. Напишите команду /anonim, чтобы начать!')
    else:
        # Проверка пароля
        if hashed_input_password == users[message.from_user.id]:
            bot.reply_to(message, 'Вы успешно вошли в систему!')
        else:
            bot.reply_to(message, 'Неверный пароль! Попробуйте снова.')

@bot.message_handler(commands=['anonim'])
def start_anonim(message):
    if message.from_user.id not in users:
        bot.reply_to(message, 'Вы не зарегистрированы. Пожалуйста, зарегистрируйтесь с помощью команды /reg.')
        return
    active_chat_users[message.from_user.id] = True
    bot.reply_to(message, 'Вы находитесь в анонимном чате! Напишите любое сообщение, и я отправлю его случайному пользователю!')

@bot.message_handler(func=lambda message: message.from_user.id in active_chat_users)
def handle_anonim_message(message):
    other_users = [uid for uid in active_chat_users if uid != message.from_user.id and active_chat_users[uid]]

    if not other_users:
        bot.reply_to(message, 'В данный момент нет доступных пользователей для общения. Пожалуйста, подождите...')
        return

    random_user_id = random.choice(other_users)
    bot.send_message(random_user_id, f"Сообщение от {message.from_user.first_name}: {message.text}")
    bot.reply_to(message, 'Ваше сообщение отправлено анонимному пользователю!')

@bot.message_handler(commands=['exit'])
def exit_chat(message):
    if message.from_user.id in active_chat_users:
        del active_chat_users[message.from_user.id]
        bot.reply_to(message, 'Вы вышли из анонимного чата.')
    else:
        bot.reply_to(message, 'Вы не находитесь в анонимном чате.')

bot.infinity_polling()